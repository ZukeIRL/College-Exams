﻿// Author : Luke Browne
// Date : 16-05-2019
// Description : This program will determine the toal number of ticket sales for an event, calculate their cost,
                         // and output this information on an easy to read table

using static System.Console;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Q1
{
    class Program
    {
        static int[] Basic = new int[15];
        static int[] Super = new int[15];
        static int[] Delux = new int[15];
        static int[] VIP = new int[15];

        static void Main(string[] args)
        {
            int a = ReadInput(); // a is the number of times required to go through the loop 
            OutputTable(a);         // this has come from the value of i below
        }

        static int ReadInput()
        {
            string[] fields = new string[3];            // Temporary storage for each line of the txt file
            string lineIn;                           // The variable used to store and pass to the fields
            int i = 0;                               // counter

            FileStream fs3 = new FileStream("ticketsales.txt", FileMode.Open, FileAccess.Read);
            StreamReader inputStream = new StreamReader(fs3);               // Reads the desired file
            lineIn = inputStream.ReadLine();                                // Reads the first line

            try
            {
                while (lineIn != null)                   // so that the loop actually begins
                {
                    fields = lineIn.Split(',');                 // specifies where a new string will begin
                    lineIn = inputStream.ReadLine();                // reads line i

                    if (fields[1] == "Basic")
                    {
                        Basic[i] = int.Parse(fields[2]);        // this takes the second value in the csv and tests it to see if the string matches up
                    }                                       // with any of the ticket types, if it does it adds the third value in the csv to the array at the top for later use
                    else if (fields[1] == "Super")
                    {
                        Super[i] = int.Parse(fields[2]);
                    }
                    else if (fields[1] == "Delux")
                    {
                        Delux[i] = int.Parse(fields[2]);
                    }
                    else if (fields[1] == "VIP")
                    {
                        VIP[i] = int.Parse(fields[2]);
                    }
                    i++;
                }
            }
            catch (IOException)
            {
                WriteLine("Error Loading Text File : Please ensure it Exists");
            }
            catch (IndexOutOfRangeException)                                     // Exception handling in case of predictable errors
            {
                WriteLine("Too many lines loaded, try increasing array sizes at top");
            }
            catch (NullReferenceException)
            {
                WriteLine("Ticket Type does not match with any we currently have on sale...");
            }
            return i;   // i is returned so we know how many times to loop through the array later
        }

        static void OutputTable(int a)
        {
            OutputEncoding = Encoding.UTF8;                     // Outputs the money value in euros
            string tableFormat = "{0, -18}{1, -18}{2, -18:c2}";         // format for table

            int totalBasic = 0, totalSuper = 0, totalDelux = 0, totalVIP = 0;   // initialises the count for number of tickets sold
            double costBasic = 40, costSuper = 45, costDelux = 55, costVIP = 60;  // sets the value for the cost of each ticket

            for (int i = 0; i < a; i++) // "int i < a" ensures we do not go through the loop more times than necessary
            {
                if(Basic[i] != 0)
                {
                    totalBasic = totalBasic + Basic[i];     // if the system detects a number in the Basic[i] array
                }                                               // it will add it to the total number of Basic Tickets
                else if(Super[i] != 0)      
                {
                    totalSuper = totalSuper + Super[i];     // Likewise with the Super, etc.
                }
                else if (Delux[i] != 0)
                {
                    totalDelux = totalDelux + Delux[i];
                }
                else if (VIP[i] != 0)
                {
                    totalVIP = totalVIP + VIP[i];
                }
            }

            double totalBasicCost = (totalBasic * costBasic), totalSuperCost = (totalSuper * costSuper);        // this multiplies the total cost of all the ticket types by using
            double totalDeluxCost = (totalDelux * costDelux), totalVIPCost = (totalVIP * costVIP);            // the number of a type of ticket found in the for loop and multiplying
                                                                                                                // it by the cost of the ticket found at the top of this Method


            int totalTickets = totalBasic + totalSuper + totalDelux + totalVIP;     // this adss the total number of all tickets sold
            double totalCost = totalBasicCost + totalSuperCost + totalDeluxCost + totalVIPCost; // and this calculates their total cost


            WriteLine(tableFormat, "Ticket Type", "Tickets Sold", "Total Retail Value");    // this the table which outputs all values
            WriteLine("------------------------------------------------------");
            WriteLine(tableFormat, "Basic", totalBasic, totalBasicCost);
            WriteLine(tableFormat, "Super", totalSuper, totalSuperCost);
            WriteLine(tableFormat, "Delux", totalDelux, totalDeluxCost);
            WriteLine(tableFormat, "VIP", totalVIP, totalVIPCost);
            WriteLine(tableFormat, "Total", totalTickets, totalCost);
        }
    }
}
