﻿// Author : Luke Browne
// Date : 16-05-2019
// Description : This is a program which uses classes and subclasses to record a bike's Brand, Price and Serial number
                // and in the case of an electric bike it also adds its power value to the end
                // the program also calculates the deposit required to be placed on the bike before purchase
                // which is 30% for a normal bike and 10% for an electric bike respectively

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Q2
{
    class Bike
    {
        public int i = 132;    // random first serial number... The "public" allows it to be accessed in other classes

        private string _brand;
        private double _price;  // Attributes
        private int _serial;
        double Deposit = 0; // initialises value for deposit required

        public Bike()
        {               // Default constructor
            i++;
            Serial = i;
        }

        public Bike(string b, double p)
        {               // Parameterised constructor
            Brand = b;
            Price = p;
            i++;
            Serial = i;
        }

        public string Brand { get => _brand; set => _brand = value; }
        public double Price { get => _price; set => _price = value; }       // getters and setters
        public int Serial { get => _serial; set => _serial = value; }

        public virtual double CalcDeposit()
        {
            double DepositReq = Price * 0.3;        // calculates the deposit at a 30% rate
            Deposit = DepositReq;
            return DepositReq;
        }

        public override string ToString()       // this is the ToString() method used back in the Program.cs
        {
            return "Brand : " + Brand + "\nPrice : " + "€" + Price + "\nSerial : " + Serial + "\nDeposit Required : " + "€" + (Price * 0.3);
        }
    }
}
