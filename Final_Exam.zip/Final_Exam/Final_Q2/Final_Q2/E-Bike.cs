﻿// Author : Luke Browne
// Date : 16-05-2019
// Description : This is a program which uses classes and subclasses to record a bike's Brand, Price and Serial number
                // and in the case of an electric bike it also adds its power value to the end
                // the program also calculates the deposit required to be placed on the bike before purchase
                // which is 30% for a normal bike and 10% for an electric bike respectively

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Q2
{
    class E_Bike : Bike     // declares the E-Bike as a subclass or child of the Bike Class
    {
        private int _power;     // Extra attribute "power" only required for E-Bikes
        double Deposit = 0;     // initialises value for deposit required

        public int Power { get => _power; set => _power = value; }  // getter and setter

        public E_Bike() : base()    // default constructor
        {

        }

        public E_Bike(string Brand, double Price, int Power) : base(Brand, Price)
        {               // parameterised constructor with reference tot the Bike Class
            _power = Power;
            i++;
            Serial = i;
        }

        public override double CalcDeposit()
        {
            double DepositReq = Price * 0.1;        // and this calculates the deposit at a 10% rate
            Deposit = DepositReq;
            return DepositReq;
        }

        public override string ToString()       // ToString() used in the Program.cs
        {
            return "Brand : " + Brand + "\nPrice : " + "€" + Price + "\nSerial Number : " + Serial + "\nPower : " + Power + "\nDeposit Required : " + "€" + (Price * 0.1);
        }
    }
}
