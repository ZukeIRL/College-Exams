﻿// Author : Luke Browne
// Date : 16-05-2019
// Description : This is a program which uses classes and subclasses to record a bike's Brand, Price and Serial number
                // and in the case of an electric bike it also adds its power value to the end
                // the program also calculates the deposit required to be placed on the bike before purchase
                // which is 30% for a normal bike and 10% for an electric bike respectively

using static System.Console;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            OutputEncoding = Encoding.UTF8; // Outputs the price and deposit values with a euro sign

            try
            {
                Bike[] bikes = new Bike[4];     // creates an array with 4 spaces for 4 bikes

                bikes[0] = new Bike("Trek", 350.50);        // first two are normal bikes with a 30% deposit
                bikes[1] = new Bike("Raleigh", 200);
                bikes[2] = new E_Bike("BMC", 459.99, 300);  // last two are Electric Bikes with a 10% deposit
                bikes[3] = new E_Bike("Giant", 700, 500);

                for (int i = 0; i < bikes.Length; i++)      // loops through the entire method
                {
                    WriteLine("Bike{0}", i + 1);
                    WriteLine("------");
                    WriteLine(bikes[i].ToString());     // and prints out each bike's ToString()
                    WriteLine(); // just a spacer
                }
            }
            catch(IndexOutOfRangeException)     // if it tries looping too many times and the array is too small this error will occur
            {
                WriteLine("Error has occurred... Try increasing your array size");
            }
            catch(Exception e)  // generic error message
            {
                WriteLine("An error has occurred");
            }
        }
    }
}
